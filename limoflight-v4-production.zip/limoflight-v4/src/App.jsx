// LimoFlight V4 — App.jsx
import { useState } from 'react'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { AuthProvider, useAuth } from './context/AuthContext'
import { NotificationProvider } from './context/NotifContext'
import { BrandProvider } from './context/BrandContext'
import SubscriptionGuard from './guards/SubscriptionGuard'
import Layout from './components/Layout'
import Dashboard from './pages/Dashboard'
import Booking from './pages/Booking'
import Tracking from './pages/Tracking'
import FaceAI from './pages/FaceAI'
import DriverApp from './pages/DriverApp'
import CapCutAI from './pages/CapCutAI'
import OpenTable from './pages/OpenTable'
import Analytics from './pages/Analytics'
import WhiteLabel from './pages/WhiteLabel'
import Billing from './pages/Billing'
import Security from './pages/Security'
import Login from './pages/Login'
import './styles/brand.css'

function PrivateRoute({ children }) {
  const { user } = useAuth()
  return user ? children : <Navigate to="/login" />
}

export default function App() {
  return (
    <AuthProvider>
      <BrandProvider>
        <NotificationProvider>
          <BrowserRouter>
            <Routes>
              <Route path="/login" element={<Login />} />
              <Route path="/" element={
                <PrivateRoute>
                  <SubscriptionGuard>
                    <Layout />
                  </SubscriptionGuard>
                </PrivateRoute>
              }>
                <Route index element={<Dashboard />} />
                <Route path="booking"    element={<Booking />} />
                <Route path="tracking"   element={<Tracking />} />
                <Route path="face-ai"    element={<FaceAI />} />
                <Route path="driver-app" element={<DriverApp />} />
                <Route path="capcut"     element={<CapCutAI />} />
                <Route path="opentable"  element={<OpenTable />} />
                <Route path="analytics"  element={<Analytics />} />
                <Route path="whitelabel" element={<WhiteLabel />} />
                <Route path="billing"    element={<Billing />} />
                <Route path="security"   element={<Security />} />
              </Route>
            </Routes>
          </BrowserRouter>
        </NotificationProvider>
      </BrandProvider>
    </AuthProvider>
  )
}

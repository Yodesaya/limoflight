// LimoFlight V4 — pages/DriverApp.jsx
import { useState } from 'react'
import { useBrand } from '../context/BrandContext'

export default function DriverApp() {
  const { brand } = useBrand()
  const [chatMsg, setChatMsg] = useState('')
  const [chatLog, setChatLog] = useState([
    { from: 'Dispatch', msg: 'Mike, LAX pickup at Gate 4 ready', color: brand.color },
    { from: 'Mike Torres', msg: 'On my way, 8 min ETA ✓', color: '#7AAAE0' },
    { from: 'Dispatch', msg: 'Sarah, reroute via Sunset Blvd', color: brand.color },
    { from: 'Sarah Kim', msg: 'Got it, rerouting now 👍', color: '#5DC48A' },
  ])

  const DRIVERS = [
    { init: 'MT', name: 'Mike Torres',  car: '#01 Lincoln MKT',       status: 'on-route',  pax: 8,  eta: '12 min', color: brand.color },
    { init: 'SK', name: 'Sarah Kim',    car: '#02 Cadillac Escalade',  status: 'on-route',  pax: 2,  eta: '6 min',  color: '#5DC48A' },
    { init: 'JL', name: 'James Lee',    car: '#03 Lincoln Navigator',  status: 'on-route',  pax: 6,  eta: '18 min', color: '#7AAAE0' },
    { init: 'AR', name: 'Ana Reyes',    car: '#04 Mercedes Sprinter',  status: 'on-route',  pax: 14, eta: '9 min',  color: '#AFA9EC' },
    { init: 'TW', name: 'Tom Walsh',    car: '#05 Cadillac CT6',       status: 'dispatched',pax: 0,  eta: '22 min', color: '#F0997B' },
  ]

  function sendChat() {
    if (!chatMsg.trim()) return
    setChatLog(l => [...l, { from: 'Dispatch', msg: chatMsg, color: brand.color }])
    setChatMsg('')
  }

  return (
    <div style={{ color: '#E8E4D9', fontFamily: "'DM Sans', sans-serif" }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
        {/* Phone mockup */}
        <div style={card}>
          <div style={ct}>Driver mobile app — preview</div>
          <div style={{ fontSize: 10, color: '#6A6560', marginBottom: 12 }}>Google Play exclusive · Auto-syncs with dashboard</div>
          <div style={{ width: 200, background: '#111118', border: '2px solid rgba(201,168,76,.2)', borderRadius: 28, padding: '10px 8px', margin: '0 auto' }}>
            <div style={{ width: 60, height: 10, background: '#08080E', borderRadius: 6, margin: '0 auto 8px' }} />
            <div style={{ background: '#08080E', borderRadius: 18, padding: 10 }}>
              <div style={{ textAlign: 'center', paddingBottom: 10 }}>
                <div style={{ width: 48, height: 48, borderRadius: '50%', background: brand.color, color: '#08080E', fontSize: 16, fontWeight: 500, display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 6px' }}>MT</div>
                <div style={{ fontSize: 13, fontWeight: 500 }}>Mike Torres</div>
                <div style={{ fontSize: 9, color: '#5DC48A' }}>Lincoln MKT #01 · Online</div>
              </div>
              <div style={{ background: '#16161F', borderRadius: 10, padding: 10, marginBottom: 8, border: '1px solid rgba(201,168,76,.15)' }}>
                <div style={{ fontSize: 8, letterSpacing: 1, textTransform: 'uppercase', color: '#6A6560', marginBottom: 5 }}>Active booking</div>
                {[['Customer','Capt. Williams'],['Pax','8 passengers'],['Destination','Beverly Hills'],['ETA',{ val: '12 min', gold: true }]].map(([l, v]) =>
                  <div key={l} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 10, padding: '2px 0' }}>
                    <span style={{ color: '#6A6560' }}>{l}</span>
                    <span style={{ color: typeof v === 'object' && v.gold ? brand.color : '#E8E4D9' }}>{typeof v === 'object' ? v.val : v}</span>
                  </div>
                )}
                <div style={{ height: 4, background: '#1C1C27', borderRadius: 2, marginTop: 6, overflow: 'hidden' }}><div style={{ height: '100%', width: '45%', background: brand.color, borderRadius: 2 }} /></div>
              </div>
              {[{ label: '🗺 Navigate', bg: brand.color, tc: '#08080E' }, { label: '✓ Confirm pickup', bg: 'rgba(58,125,90,.15)', tc: '#5DC48A' }, { label: '⚠ SOS / Emergency', bg: 'rgba(139,51,51,.2)', tc: '#D47A7A' }].map(b => (
                <button key={b.label} style={{ width: '100%', padding: 7, borderRadius: 8, fontSize: 10, fontFamily: 'inherit', cursor: 'pointer', background: b.bg, color: b.tc, border: 'none', marginBottom: 5, fontWeight: 500 }}>{b.label}</button>
              ))}
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 8, color: '#3A3830', paddingTop: 5, borderTop: '1px solid rgba(201,168,76,.1)' }}>
                <span>🛰 GPS on</span><span>4G · 98% 🔋</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right: drivers + chat */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <div style={card}>
            <div style={ct}>All drivers — live status</div>
            {DRIVERS.map(d => (
              <div key={d.init} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '7px 0', borderBottom: '1px solid rgba(255,255,255,.04)' }}>
                <div style={{ width: 30, height: 30, borderRadius: '50%', background: d.color + '30', color: d.color, fontSize: 11, fontWeight: 500, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>{d.init}</div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 11, fontWeight: 500 }}>{d.name}</div>
                  <div style={{ fontSize: 9, color: '#6A6560' }}>{d.car} · {d.pax > 0 ? d.pax + ' pax' : 'empty'}</div>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <div style={{ background: d.status === 'on-route' ? 'rgba(58,125,90,.15)' : 'rgba(201,168,76,.12)', color: d.status === 'on-route' ? '#5DC48A' : '#C9A84C', fontSize: 9, padding: '1px 7px', borderRadius: 10, marginBottom: 2 }}>{d.status}</div>
                  <div style={{ fontSize: 9, color: d.color }}>ETA {d.eta}</div>
                </div>
              </div>
            ))}
          </div>
          <div style={card}>
            <div style={ct}>Dispatch chat</div>
            <div style={{ background: '#1C1C27', borderRadius: 8, padding: 8, height: 120, overflowY: 'auto', fontSize: 10, display: 'flex', flexDirection: 'column', gap: 5, marginBottom: 8 }}>
              {chatLog.map((m, i) => <div key={i}><span style={{ color: m.color, fontWeight: 500 }}>{m.from}:</span> {m.msg}</div>)}
            </div>
            <div style={{ display: 'flex', gap: 6 }}>
              <input style={{ ...inp, flex: 1 }} placeholder="Send dispatch message..." value={chatMsg} onChange={e => setChatMsg(e.target.value)} onKeyDown={e => e.key === 'Enter' && sendChat()} />
              <button onClick={sendChat} style={{ padding: '7px 12px', borderRadius: 7, background: brand.color, color: '#08080E', border: 'none', cursor: 'pointer', fontSize: 12 }}>↑</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

// ─────────────────────────────────────────────────────────────────────────────
// pages/CapCutAI.jsx
// ─────────────────────────────────────────────────────────────────────────────
export function CapCutAI() {
  const { brand } = useBrand()
  const [generating, setGenerating] = useState(false)
  const [progress, setProgress] = useState(0)
  const [step, setStep] = useState('')
  const [reels, setReels] = useState([
    { title: 'Beverly Hills Tour', dur: '47 sec', res: '4K', date: 'Today', views: 142, status: 'ready' },
    { title: 'Jazz District Night', dur: '31 sec', res: '4K', date: 'Yesterday', views: 89, status: 'ready' },
    { title: 'Hollywood Sign Loop', dur: '58 sec', res: '1080p', date: 'Jun 5', views: 204, status: 'ready' },
  ])

  const STEPS = ['Analyzing footage...', 'Detecting highlights...', 'Syncing to music...', 'Applying AI effects...', 'Rendering 4K output...', 'Finalizing reel...']
  const EFFECTS = [
    { icon: 'ti-sun', label: 'Golden hour', sel: true },
    { icon: 'ti-movie', label: 'Cinematic', sel: false },
    { icon: 'ti-layout-grid', label: 'Split-screen', sel: false },
    { icon: 'ti-text-size', label: 'Auto captions', sel: true },
    { icon: 'ti-map', label: 'Route overlay', sel: false },
    { icon: 'ti-music', label: 'Beat sync', sel: false },
    { icon: 'ti-brand-instagram', label: '9:16 crop', sel: false },
    { icon: 'ti-color-filter', label: 'Color grade', sel: true },
  ]
  const [effects, setEffects] = useState(EFFECTS)

  function generate() {
    setGenerating(true); setProgress(0)
    let p = 0, si = 0
    const iv = setInterval(() => {
      p = Math.min(p + 3 + Math.random() * 4, 100)
      setProgress(Math.round(p))
      setStep(STEPS[Math.min(si++, STEPS.length - 1)])
      if (p >= 100) {
        clearInterval(iv)
        setGenerating(false)
        setReels(r => [{ title: 'Downtown LA Cruise', dur: '44 sec', res: '4K', date: 'Just now', views: 0, status: 'ready' }, ...r])
      }
    }, 220)
  }

  return (
    <div style={{ color: '#E8E4D9', fontFamily: "'DM Sans', sans-serif" }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
        <div>
          <div style={{ ...card, marginBottom: 12 }}>
            <div style={ct}>AI highlight reel generator</div>
            <div style={{ display: 'inline-flex', alignItems: 'center', gap: 5, padding: '4px 10px', background: 'rgba(83,74,183,.15)', border: '1px solid rgba(83,74,183,.25)', borderRadius: 20, fontSize: 10, color: '#AFA9EC', marginBottom: 10 }}>✨ Powered by CapCut AI · Auto-edit enabled</div>
            {[['Tour source','select',['Beverly Hills Tour — Today 2:30 PM','Jazz District Night — Yesterday','Hollywood Sign + Griffith — Jun 5']],['Reel style','select',['Cinematic luxury','Fast-cut energetic','Vlog travel diary','Social media short']],['Duration','select',['15 sec (Instagram)','30 sec (TikTok)','60 sec (YouTube Shorts)']],['AI music','select',['Jazz lounge','Epic cinematic','Upbeat pop','Lo-fi chill']]].map(([l, t, opts]) => (
              <div key={l} style={fg}>
                <label style={lbl}>{l}</label>
                <select style={inp}>{opts.map(o => <option key={o}>{o}</option>)}</select>
              </div>
            ))}
            {generating && (
              <div style={{ marginBottom: 10 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 10, marginBottom: 3 }}>
                  <span style={{ color: '#6A6560' }}>{step}</span>
                  <span style={{ color: brand.color }}>{progress}%</span>
                </div>
                <div style={{ height: 4, background: '#1C1C27', borderRadius: 2, overflow: 'hidden' }}>
                  <div style={{ height: '100%', background: brand.color, borderRadius: 2, width: progress + '%', transition: 'width .15s' }} />
                </div>
              </div>
            )}
            <button onClick={generate} disabled={generating} style={{ width: '100%', padding: 9, borderRadius: 8, background: brand.color, color: '#08080E', border: 'none', fontFamily: 'inherit', fontSize: 12, fontWeight: 500, cursor: 'pointer', opacity: generating ? 0.7 : 1 }}>
              {generating ? 'Generating...' : '✨ Generate AI reel'}
            </button>
          </div>
          <div style={card}>
            <div style={ct}>AI effects & filters</div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 6 }}>
              {effects.map((ef, i) => (
                <div key={ef.label} onClick={() => setEffects(e => e.map((x, j) => j === i ? { ...x, sel: !x.sel } : x))}
                  style={{ background: '#1C1C27', border: `1px solid ${ef.sel ? brand.color : 'rgba(201,168,76,.15)'}`, borderRadius: 7, padding: '7px 4px', textAlign: 'center', cursor: 'pointer', color: ef.sel ? brand.color : '#6A6560' }}>
                  <i className={`ti ${ef.icon}`} style={{ display: 'block', fontSize: 16, marginBottom: 3 }} />
                  <div style={{ fontSize: 8 }}>{ef.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
        <div style={card}>
          <div style={ct}>Reel library</div>
          {reels.map((r, i) => (
            <div key={i} style={{ background: '#1C1C27', border: '1px solid rgba(201,168,76,.15)', borderRadius: 8, padding: 10, marginBottom: 8, display: 'flex', alignItems: 'center', gap: 10 }}>
              <div style={{ width: 50, height: 38, borderRadius: 6, background: '#16161F', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                {r.status === 'generating' ? <span style={{ fontSize: 14, color: '#AFA9EC' }}>⟳</span> : <span style={{ fontSize: 14, color: brand.color }}>▶</span>}
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 11, fontWeight: 500 }}>{r.title}</div>
                <div style={{ fontSize: 9, color: '#6A6560' }}>{r.dur} · {r.res} · {r.date}{r.views > 0 ? ` · ${r.views} views` : ''}</div>
              </div>
              {r.status === 'ready' && <div style={{ display: 'flex', gap: 5 }}>
                <button style={{ padding: '4px 8px', borderRadius: 6, fontSize: 9, cursor: 'pointer', background: '#1C1C27', border: '1px solid rgba(201,168,76,.2)', color: '#E8E4D9' }}>↗ Share</button>
                <button style={{ padding: '4px 8px', borderRadius: 6, fontSize: 9, cursor: 'pointer', background: '#1C1C27', border: '1px solid rgba(201,168,76,.2)', color: '#E8E4D9' }}>↓</button>
              </div>}
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

// ─────────────────────────────────────────────────────────────────────────────
// context/AuthContext.jsx
// ─────────────────────────────────────────────────────────────────────────────
import { createContext, useContext, useState } from 'react'
import axios from 'axios'

const AuthCtx = createContext(null)
const API = import.meta.env.VITE_API_URL

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    try { return JSON.parse(localStorage.getItem('lf_user')) } catch { return null }
  })

  async function login(email, password, twoFACode) {
    const { data } = await axios.post(`${API}/api/auth/login`, { email, password, twoFACode })
    if (data.requires2FA) return { requires2FA: true }
    localStorage.setItem('lf_user', JSON.stringify(data.user))
    localStorage.setItem('lf_token', data.token)
    axios.defaults.headers.common['Authorization'] = `Bearer ${data.token}`
    setUser(data.user)
    return data
  }

  function logout() {
    localStorage.removeItem('lf_user'); localStorage.removeItem('lf_token')
    delete axios.defaults.headers.common['Authorization']
    setUser(null)
  }

  return <AuthCtx.Provider value={{ user, login, logout }}>{children}</AuthCtx.Provider>
}
export const useAuth = () => useContext(AuthCtx)

// ─────────────────────────────────────────────────────────────────────────────
// context/BrandContext.jsx
// ─────────────────────────────────────────────────────────────────────────────
import { createContext, useContext, useState } from 'react'

const BrandCtx = createContext(null)
const DEFAULT = { name: 'LimoFlight', tagline: 'Pilot Tour Services', logo: '✈', color: '#C9A84C', font: 'Playfair Display' }

export function BrandProvider({ children }) {
  const [brand, setBrand] = useState(() => {
    try { return { ...DEFAULT, ...JSON.parse(localStorage.getItem('lf_brand')) } } catch { return DEFAULT }
  })
  return <BrandCtx.Provider value={{ brand, setBrand }}>{children}</BrandCtx.Provider>
}
export const useBrand = () => useContext(BrandCtx)

// ─────────────────────────────────────────────────────────────────────────────
// context/NotifContext.jsx
// ─────────────────────────────────────────────────────────────────────────────
import { createContext, useContext, useState, useCallback } from 'react'

const NotifCtx = createContext(null)

export function NotificationProvider({ children }) {
  const [notifs, setNotifs] = useState([])

  const addNotif = useCallback((n) => {
    setNotifs(prev => [{ ...n, id: Date.now(), unread: true, time: 'Just now' }, ...prev].slice(0, 20))
  }, [])

  const markRead = (id) => setNotifs(prev => prev.map(n => n.id === id ? { ...n, unread: false } : n))
  const clearAll = () => setNotifs(prev => prev.map(n => ({ ...n, unread: false })))
  const unreadCount = notifs.filter(n => n.unread).length

  return <NotifCtx.Provider value={{ notifs, addNotif, markRead, clearAll, unreadCount }}>{children}</NotifCtx.Provider>
}
export const useNotif = () => useContext(NotifCtx)

// ─────────────────────────────────────────────────────────────────────────────
// guards/SubscriptionGuard.jsx
// ─────────────────────────────────────────────────────────────────────────────
import { useAuth } from '../context/AuthContext'
import { useBrand } from '../context/BrandContext'
import { isFeatureAllowed } from '../api/billing'

export default function SubscriptionGuard({ children }) {
  const { user } = useAuth()
  const { brand } = useBrand()
  const plan = user?.plan || 'free'

  // Check current route against plan
  const path = window.location.pathname
  const GATED = { '/face-ai': 'face_ai', '/tracking': 'gps_tracking', '/whitelabel': 'white_label', '/analytics': 'analytics_ai', '/opentable': 'open_table', '/capcut': 'capcut' }
  const feature = GATED[path]

  if (feature && !isFeatureAllowed(plan, feature)) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: 400, color: '#E8E4D9', fontFamily: "'DM Sans', sans-serif" }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: 40, marginBottom: 12 }}>🔒</div>
          <div style={{ fontSize: 16, fontWeight: 500, marginBottom: 6 }}>Feature locked</div>
          <div style={{ fontSize: 12, color: '#6A6560', marginBottom: 20 }}>This feature requires a higher subscription tier.</div>
          <button style={{ padding: '9px 20px', borderRadius: 8, background: brand.color, color: '#08080E', border: 'none', fontFamily: 'inherit', fontSize: 12, fontWeight: 500, cursor: 'pointer' }}
            onClick={() => window.location.href = '/billing'}>
            View plans
          </button>
        </div>
      </div>
    )
  }
  return children
}

// ─────────────────────────────────────────────────────────────────────────────
// components/Layout.jsx
// ─────────────────────────────────────────────────────────────────────────────
import { Outlet, useNavigate, useLocation } from 'react-router-dom'
import { useState } from 'react'
import { useAuth } from '../context/AuthContext'
import { useBrand } from '../context/BrandContext'
import { useNotif } from '../context/NotifContext'

export default function Layout() {
  const { user, logout } = useAuth()
  const { brand } = useBrand()
  const { notifs, markRead, clearAll, unreadCount } = useNotif()
  const navigate = useNavigate()
  const location = useLocation()
  const [showNotifs, setShowNotifs] = useState(false)

  const NAV = [
    { section: 'Main', items: [
      { path: '/', label: 'Dashboard', icon: 'ti-layout-dashboard' },
      { path: '/booking', label: 'New Booking', icon: 'ti-calendar-plus' },
      { path: '/tracking', label: 'Live Tracking', icon: 'ti-map-pin', badge: '5' },
    ]},
    { section: 'Tools', items: [
      { path: '/face-ai',    label: 'Face AI',    icon: 'ti-scan' },
      { path: '/driver-app', label: 'Driver App', icon: 'ti-device-mobile' },
      { path: '/capcut',     label: 'CapCut AI',  icon: 'ti-video' },
    ]},
    { section: 'Business', items: [
      { path: '/opentable',  label: 'OpenTable',  icon: 'ti-building-store' },
      { path: '/analytics',  label: 'Analytics',  icon: 'ti-brain' },
      { path: '/whitelabel', label: 'White-label',icon: 'ti-brush' },
    ]},
    { section: 'Finance', items: [
      { path: '/billing',  label: 'Billing',  icon: 'ti-credit-card' },
      { path: '/security', label: 'Security', icon: 'ti-shield-check' },
    ]},
  ]

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '196px 1fr', gridTemplateRows: '46px 1fr', height: '100vh', overflow: 'hidden', fontFamily: "'DM Sans', sans-serif", background: '#08080E', color: '#E8E4D9' }}>
      {/* TOPBAR */}
      <div style={{ gridColumn: '1/-1', background: '#111118', borderBottom: '1px solid rgba(201,168,76,.15)', display: 'flex', alignItems: 'center', padding: '0 14px', gap: 12, position: 'relative', zIndex: 20 }}>
        <div style={{ fontFamily: `'${brand.font}', serif`, fontSize: 15, color: brand.color, whiteSpace: 'nowrap', marginRight: 6 }}>{brand.logo} {brand.name}</div>
        <div style={{ flex: 1 }} />
        {/* Notification bell */}
        <div style={{ position: 'relative' }}>
          <button onClick={() => setShowNotifs(v => !v)} style={{ width: 30, height: 30, borderRadius: 7, background: '#1C1C27', border: '1px solid rgba(201,168,76,.18)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: '#E8E4D9', position: 'relative' }}>
            <i className="ti ti-bell" style={{ fontSize: 14 }} />
            {unreadCount > 0 && <div style={{ position: 'absolute', top: -4, right: -4, width: 15, height: 15, borderRadius: '50%', background: '#D47A7A', color: '#fff', fontSize: 8, fontWeight: 500, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{unreadCount}</div>}
          </button>
          {showNotifs && (
            <div style={{ position: 'absolute', top: 36, right: 0, width: 280, background: '#16161F', border: '1px solid rgba(201,168,76,.18)', borderRadius: 10, zIndex: 50, maxHeight: 380, overflowY: 'auto' }}>
              <div style={{ padding: '8px 12px', borderBottom: '1px solid rgba(201,168,76,.12)', display: 'flex', justifyContent: 'space-between', fontSize: 10, fontWeight: 500 }}>
                Notifications <span style={{ color: '#6A6560', cursor: 'pointer' }} onClick={clearAll}>Clear all</span>
              </div>
              {notifs.length === 0 && <div style={{ padding: 16, fontSize: 11, color: '#6A6560', textAlign: 'center' }}>No notifications</div>}
              {notifs.map(n => <div key={n.id} onClick={() => markRead(n.id)} style={{ padding: '9px 12px', borderBottom: '1px solid rgba(255,255,255,.04)', cursor: 'pointer', background: n.unread ? 'rgba(201,168,76,.03)' : 'transparent' }}>
                <div style={{ fontSize: 10, fontWeight: 500, color: n.unread ? '#E8E4D9' : '#6A6560' }}>{n.title}</div>
                <div style={{ fontSize: 9, color: '#6A6560', marginTop: 1 }}>{n.body}</div>
                <div style={{ fontSize: 8, color: '#3A3830', marginTop: 2 }}>{n.time}</div>
              </div>)}
            </div>
          )}
        </div>
        <div style={{ width: 26, height: 26, borderRadius: '50%', background: brand.color, color: '#08080E', fontSize: 10, fontWeight: 500, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          {user?.full_name?.slice(0, 2).toUpperCase() || 'AD'}
        </div>
        <span style={{ fontSize: 10, color: '#6A6560' }}>{user?.full_name}</span>
        <span style={{ background: 'rgba(83,74,183,.2)', color: '#AFA9EC', fontSize: 9, padding: '1px 7px', borderRadius: 10 }}>{user?.plan || 'fleet'}</span>
        <button onClick={logout} style={{ fontSize: 10, color: '#6A6560', background: 'none', border: 'none', cursor: 'pointer' }}>Sign out</button>
      </div>

      {/* SIDEBAR */}
      <div style={{ background: '#111118', borderRight: '1px solid rgba(201,168,76,.15)', overflowY: 'auto', padding: '8px 0' }}>
        {NAV.map(({ section, items }) => (
          <div key={section}>
            <div style={{ fontSize: 8, letterSpacing: 1.5, textTransform: 'uppercase', color: '#3A3830', padding: '8px 12px 3px' }}>{section}</div>
            {items.map(item => (
              <div key={item.path} onClick={() => navigate(item.path)}
                style={{ display: 'flex', alignItems: 'center', gap: 7, padding: '7px 12px', fontSize: 11, color: location.pathname === item.path ? brand.color : '#6A6560', cursor: 'pointer', background: location.pathname === item.path ? 'rgba(201,168,76,.06)' : 'transparent', borderLeft: `2px solid ${location.pathname === item.path ? brand.color : 'transparent'}`, transition: '.15s' }}>
                <i className={`ti ${item.icon}`} style={{ fontSize: 14, width: 15 }} />
                {item.label}
                {item.badge && <span style={{ marginLeft: 'auto', background: 'rgba(201,168,76,.12)', color: brand.color, fontSize: 8, padding: '1px 5px', borderRadius: 8 }}>{item.badge}</span>}
              </div>
            ))}
          </div>
        ))}
      </div>

      {/* MAIN CONTENT */}
      <div style={{ overflowY: 'auto', background: '#08080E', padding: 14 }}>
        <Outlet />
      </div>
    </div>
  )
}

// shared style tokens used inside this file
const card = { background: '#16161F', border: '1px solid rgba(201,168,76,.15)', borderRadius: 10, padding: 13 }
const ct   = { fontSize: 8, letterSpacing: 1.4, textTransform: 'uppercase', color: '#6A6560', marginBottom: 10 }
const fg   = { marginBottom: 9 }
const lbl  = { display: 'block', fontSize: 8, letterSpacing: 1, textTransform: 'uppercase', color: '#6A6560', marginBottom: 4 }
const inp  = { width: '100%', padding: '7px 10px', background: '#1C1C27', border: '1px solid rgba(201,168,76,.18)', borderRadius: 6, color: '#E8E4D9', fontFamily: 'inherit', fontSize: 12, outline: 'none', boxSizing: 'border-box' }

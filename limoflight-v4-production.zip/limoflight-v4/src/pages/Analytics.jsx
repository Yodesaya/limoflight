// LimoFlight V4 — pages/Analytics.jsx
import { useEffect, useRef } from 'react'
import { useBrand } from '../context/BrandContext'
import { Chart, registerables } from 'chart.js'
Chart.register(...registerables)

const INSIGHTS = [
  { icon: 'ti-trending-up', title: 'Peak window: Friday 7–11 PM', body: 'Pilots on layover peak Friday nights. Recommend surge pricing +15% and 3 extra vehicles. Projected uplift: +$1,200/week.' },
  { icon: 'ti-map-pin',     title: 'Top route: LAX → Beverly Hills', body: '34% of all rides. Adding a Sprinter for groups 8+ would reduce refusals by 22% and add $800/week.' },
  { icon: 'ti-users',       title: 'VIP segment growing fast', body: 'Pilots with 5+ rides = 31% of revenue. A "LimoGold" loyalty tier could increase retention by 40%.' },
]

const KPI = [
  { label: 'Fleet utilization',  val: 78,  target: 85,  unit: '%' },
  { label: 'On-time arrival',    val: 91,  target: 95,  unit: '%' },
  { label: 'Customer rating',    val: 96,  target: 95,  unit: '%' },
  { label: 'Revenue per driver', val: 480, target: 500, unit: '$' },
  { label: 'Venue commission',   val: 840, target: 1000,unit: '$' },
]

export default function Analytics() {
  const { brand } = useBrand()
  const forecastRef = useRef(null)
  const pieRef = useRef(null)
  const fcInstance = useRef(null)
  const pieInstance = useRef(null)

  useEffect(() => {
    buildForecast(); buildPie()
    return () => { fcInstance.current?.destroy(); pieInstance.current?.destroy() }
  }, [brand.color])

  function buildForecast() {
    fcInstance.current?.destroy()
    const ctx = forecastRef.current?.getContext('2d')
    if (!ctx) return
    const hist = [38200, 41000, 39500, 43800, 46200, 48200]
    const fore = [48200, 49800, 51200, 52400, 54000, 55800, 53200]
    fcInstance.current = new Chart(ctx, {
      type: 'line',
      data: {
        labels: ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'].slice(0, hist.length + fore.length - 1),
        datasets: [
          { label: 'Actual', data: [...hist, ...Array(fore.length - 1).fill(null)], borderColor: brand.color, backgroundColor: brand.color + '22', fill: true, tension: 0.4, pointRadius: 2 },
          { label: 'AI Forecast', data: [...Array(hist.length - 1).fill(null), ...fore], borderColor: '#AFA9EC', borderDash: [5, 4], backgroundColor: 'rgba(83,74,183,.1)', fill: true, tension: 0.4, pointRadius: 2 },
        ],
      },
      options: { plugins: { legend: { labels: { color: '#6A6560', font: { size: 9 }, boxWidth: 10 } } }, scales: { x: { grid: { color: 'rgba(255,255,255,.04)' }, ticks: { color: '#6A6560', font: { size: 9 } } }, y: { grid: { color: 'rgba(255,255,255,.04)' }, ticks: { color: '#6A6560', font: { size: 9 }, callback: v => '$' + v.toLocaleString() } } } },
    })
  }

  function buildPie() {
    pieInstance.current?.destroy()
    const ctx = pieRef.current?.getContext('2d')
    if (!ctx) return
    pieInstance.current = new Chart(ctx, {
      type: 'doughnut',
      data: { labels: ['Los Angeles', 'Las Vegas', 'New York', 'Miami', 'New Orleans'], datasets: [{ data: [38, 26, 20, 10, 6], backgroundColor: [brand.color, '#5DC48A', '#7AAAE0', '#AFA9EC', '#F0997B'], borderWidth: 0, hoverOffset: 4 }] },
      options: { plugins: { legend: { position: 'right', labels: { color: '#6A6560', font: { size: 9 }, boxWidth: 10, padding: 8 } } }, cutout: '65%' },
    })
  }

  return (
    <div style={{ color: '#E8E4D9', fontFamily: "'DM Sans', sans-serif" }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 12 }}>
        <div style={card}><div style={ct}>Revenue forecast — 12 months</div><canvas ref={forecastRef} height={130} /></div>
        <div style={card}><div style={ct}>Rides by city</div><canvas ref={pieRef} height={130} /></div>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
        <div style={card}>
          <div style={ct}>AI insights</div>
          {INSIGHTS.map((ins, i) => (
            <div key={i} style={{ background: 'rgba(83,74,183,.15)', border: '1px solid rgba(83,74,183,.25)', borderRadius: 9, padding: 10, marginBottom: 8 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 4 }}>
                <i className={`ti ${ins.icon}`} style={{ fontSize: 14, color: '#AFA9EC' }} />
                <div style={{ fontSize: 11, fontWeight: 500, color: '#AFA9EC' }}>{ins.title}</div>
              </div>
              <div style={{ fontSize: 10, color: '#6A6560', lineHeight: 1.6 }}>{ins.body}</div>
            </div>
          ))}
        </div>
        <div style={card}>
          <div style={ct}>KPI performance</div>
          {KPI.map((k, i) => (
            <div key={i} style={{ marginBottom: 10 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 10, marginBottom: 3 }}>
                <span style={{ color: '#6A6560' }}>{k.label}</span>
                <span style={{ color: k.val >= k.target ? '#5DC48A' : '#C9A84C', fontWeight: 500 }}>
                  {k.unit === '$' ? '$' + k.val : k.val + k.unit} <span style={{ color: '#6A6560', fontSize: 9 }}>/ {k.unit === '$' ? '$' + k.target : k.target + k.unit}</span>
                </span>
              </div>
              <div style={{ height: 4, background: '#1C1C27', borderRadius: 2, overflow: 'hidden' }}>
                <div style={{ height: '100%', borderRadius: 2, background: k.val >= k.target ? '#5DC48A' : '#C9A84C', width: Math.min(Math.round(k.val / k.target * 100), 100) + '%', transition: 'width .5s' }} />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

// ─────────────────────────────────────────────────────────────────────────────
// pages/WhiteLabel.jsx
// ─────────────────────────────────────────────────────────────────────────────
export function WhiteLabel() {
  const { brand, setBrand } = useBrand()
  const colors = ['#C9A84C', '#2A7FFF', '#D85A30', '#1D9E75', '#8B3F9E', '#D4537E']
  const emojis = ['✈', '🚗', '🌟', '💎', '🛩', '👑']

  function save() {
    localStorage.setItem('lf_brand', JSON.stringify(brand))
    alert('✓ Brand saved & applied to all clients!')
  }

  return (
    <div style={{ color: '#E8E4D9', fontFamily: "'DM Sans', sans-serif" }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
        <div>
          <div style={{ ...card, marginBottom: 12 }}>
            <div style={ct}>Brand identity</div>
            <div style={fg}><label style={lbl}>Company name</label><input style={inp} value={brand.name} onChange={e => setBrand(b => ({ ...b, name: e.target.value }))} /></div>
            <div style={fg}><label style={lbl}>Tagline</label><input style={inp} value={brand.tagline} onChange={e => setBrand(b => ({ ...b, tagline: e.target.value }))} /></div>
            <div style={fg}>
              <label style={lbl}>Logo symbol</label>
              <div style={{ display: 'flex', gap: 6, marginTop: 4 }}>
                {emojis.map(em => <div key={em} onClick={() => setBrand(b => ({ ...b, logo: em }))} style={{ width: 32, height: 32, borderRadius: 7, border: `1px solid ${brand.logo === em ? brand.color : 'rgba(201,168,76,.2)'}`, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', fontSize: 16, background: brand.logo === em ? brand.color + '20' : '#1C1C27' }}>{em}</div>)}
              </div>
            </div>
            <div style={fg}>
              <label style={lbl}>Primary color</label>
              <div style={{ display: 'flex', gap: 7, marginTop: 4, flexWrap: 'wrap' }}>
                {colors.map(c => <div key={c} onClick={() => setBrand(b => ({ ...b, color: c }))} style={{ width: 28, height: 28, borderRadius: 6, background: c, cursor: 'pointer', border: `2px solid ${brand.color === c ? '#fff' : 'transparent'}`, outline: brand.color === c ? `2px solid ${c}` : 'none', outlineOffset: 2 }} />)}
                <input type="color" value={brand.color} onChange={e => setBrand(b => ({ ...b, color: e.target.value }))} style={{ width: 28, height: 28, padding: 2, borderRadius: 6, cursor: 'pointer', border: '1px solid rgba(201,168,76,.2)' }} />
              </div>
            </div>
            <div style={fg}>
              <label style={lbl}>Font</label>
              <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginTop: 4 }}>
                {['Playfair Display', 'DM Sans', 'Georgia', 'monospace'].map(f => <div key={f} onClick={() => setBrand(b => ({ ...b, font: f }))} style={{ padding: '5px 10px', borderRadius: 20, fontSize: 10, cursor: 'pointer', border: `1px solid ${brand.font === f ? brand.color : 'rgba(201,168,76,.2)'}`, color: brand.font === f ? brand.color : '#6A6560', fontFamily: f, background: '#1C1C27' }}>{f.split(' ')[0]}</div>)}
              </div>
            </div>
          </div>
          <button onClick={save} style={{ ...btnPrimary, background: brand.color, width: '100%', justifyContent: 'center', color: '#08080E' }}>✓ Save & apply branding</button>
        </div>
        {/* Live preview */}
        <div style={card}>
          <div style={ct}>Live preview</div>
          <div style={{ background: '#08080E', border: '1px solid rgba(201,168,76,.15)', borderRadius: 10, overflow: 'hidden' }}>
            <div style={{ padding: '8px 12px', background: '#111118', borderBottom: '1px solid rgba(201,168,76,.12)', display: 'flex', alignItems: 'center' }}>
              <span style={{ fontFamily: `'${brand.font}', serif`, fontSize: 14, color: brand.color }}>{brand.logo} {brand.name}</span>
            </div>
            <div style={{ padding: 14 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14 }}>
                <div style={{ width: 40, height: 40, borderRadius: '50%', background: brand.color, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18, color: '#08080E' }}>{brand.logo}</div>
                <div>
                  <div style={{ fontSize: 13, fontWeight: 500, fontFamily: `'${brand.font}', serif` }}>Welcome to {brand.name}</div>
                  <div style={{ fontSize: 10, color: '#6A6560' }}>{brand.tagline} · Los Angeles</div>
                </div>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 7, marginBottom: 12 }}>
                {['12 rides', '$3.8k', '4.9★'].map((v, i) => <div key={i} style={{ background: '#16161F', borderRadius: 8, padding: 9, textAlign: 'center', border: '1px solid rgba(201,168,76,.12)' }}><div style={{ fontSize: 14, fontWeight: 500, color: brand.color }}>{v}</div></div>)}
              </div>
              <button style={{ width: '100%', padding: 8, borderRadius: 8, background: brand.color, color: '#08080E', fontFamily: `'${brand.font}', serif`, fontSize: 11, fontWeight: 500, border: 'none', cursor: 'pointer' }}>Book a Ride</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

// ─────────────────────────────────────────────────────────────────────────────
// pages/OpenTable.jsx
// ─────────────────────────────────────────────────────────────────────────────
export function OpenTable() {
  const { brand } = useBrand()
  const VENUES = [
    { em: '🥩', name: 'Spago Beverly Hills',  type: 'Fine dining',    rating: '4.9', avail: '8 PM open',   comm: '8%',  age: 'All ages' },
    { em: '🍣', name: 'Nobu Malibu',           type: 'Japanese',       rating: '4.8', avail: '7:30 open',   comm: '10%', age: 'All ages' },
    { em: '🍷', name: 'Catch LA',              type: 'American / Bar', rating: '4.6', avail: '9 PM open',   comm: '9%',  age: 'All ages' },
    { em: '🥂', name: "Perino's Rooftop",     type: 'Italian',        rating: '4.7', avail: '7 PM open',   comm: '11%', age: 'All ages' },
    { em: '🍸', name: 'SkyBar Mondrian',       type: 'Bar / Lounge',   rating: '4.5', avail: '10 PM open',  comm: '12%', age: '21+' },
    { em: '🦞', name: 'Water Grill',           type: 'Seafood',        rating: '4.9', avail: '6:30 open',   comm: '8%',  age: 'All ages' },
  ]
  return (
    <div style={{ color: '#E8E4D9', fontFamily: "'DM Sans', sans-serif" }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 12 }}>
        <div style={card}>
          <div style={ct}>OpenTable API status</div>
          {[['Status','✓ Live',true],['Venues','38 restaurants · 24 bars',false],['Today reservations','7 booked',false],['Commission earned','$840',false]].map(([l,v,ok]) =>
            <div key={l} style={{ display: 'flex', justifyContent: 'space-between', padding: '5px 0', borderBottom: '1px solid rgba(255,255,255,.04)', fontSize: 11 }}>
              <span style={{ color: '#6A6560' }}>{l}</span><span style={{ color: ok ? '#5DC48A' : '#E8E4D9' }}>{v}</span>
            </div>
          )}
        </div>
        <div style={card}>
          <div style={ct}>Quick reservation</div>
          {['Customer','Date & time','Party size','Cuisine'].map((l, i) => <div key={i} style={fg}><label style={lbl}>{l}</label><input style={inp} placeholder={l === 'Date & time' ? '' : l + '...'} type={l === 'Date & time' ? 'datetime-local' : 'text'} /></div>)}
          <button style={{ ...btnPrimary, background: brand.color, color: '#08080E', width: '100%', justifyContent: 'center', border: 'none' }}>🔍 Find & book table</button>
        </div>
      </div>
      <div style={card}>
        <div style={ct}>Recommended venues — Los Angeles</div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 9 }}>
          {VENUES.map(v => (
            <div key={v.name} style={{ background: '#1C1C27', border: '1px solid rgba(201,168,76,.15)', borderRadius: 9, padding: 10, cursor: 'pointer' }}>
              <div style={{ fontSize: 24, marginBottom: 6 }}>{v.em}</div>
              <div style={{ fontSize: 11, fontWeight: 500, marginBottom: 2 }}>{v.name}</div>
              <div style={{ fontSize: 9, color: '#6A6560', marginBottom: 5 }}>{v.type} · {v.age}</div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontSize: 9, color: brand.color }}>★ {v.rating} · {v.avail}</span>
                <span style={{ fontSize: 9, background: 'rgba(58,125,90,.15)', color: '#5DC48A', padding: '1px 6px', borderRadius: 10 }}>{v.comm}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

// ─────────────────────────────────────────────────────────────────────────────
// pages/Billing.jsx
// ─────────────────────────────────────────────────────────────────────────────
export function Billing() {
  const { brand } = useBrand()
  const PLANS = [
    { name: 'Free', price: 0, period: 'forever', features: ['5 bookings/mo','1 driver','Basic dashboard'], locked: ['Face AI','WhatsApp','GPS tracking','White-label'], color: '#6A6560' },
    { name: 'Pro', price: 49, period: '/month', features: ['Unlimited bookings','5 drivers','Face AI','WhatsApp','Partner venues','Reports'], locked: ['GPS tracking','White-label'], color: brand.color, popular: true },
    { name: 'Fleet', price: 149, period: '/month', features: ['Everything in Pro','Unlimited drivers','GPS tracking','White-label branding','CapCut AI reels','Priority support'], locked: [], color: '#AFA9EC', current: true },
  ]
  return (
    <div style={{ color: '#E8E4D9', fontFamily: "'DM Sans', sans-serif" }}>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 12, marginBottom: 12 }}>
        {PLANS.map(p => (
          <div key={p.name} style={{ background: '#16161F', border: `${p.current ? 2 : 1}px solid ${p.current ? p.color : 'rgba(201,168,76,.15)'}`, borderRadius: 12, padding: 16, position: 'relative' }}>
            {p.popular && !p.current && <div style={{ position: 'absolute', top: -10, left: '50%', transform: 'translateX(-50%)', background: brand.color, color: '#08080E', fontSize: 9, fontWeight: 500, padding: '2px 10px', borderRadius: 20, whiteSpace: 'nowrap' }}>Most popular</div>}
            {p.current && <div style={{ position: 'absolute', top: -10, left: '50%', transform: 'translateX(-50%)', background: p.color, color: '#08080E', fontSize: 9, fontWeight: 500, padding: '2px 10px', borderRadius: 20, whiteSpace: 'nowrap' }}>Current plan</div>}
            <div style={{ fontSize: 14, fontWeight: 500, marginBottom: 4 }}>{p.name}</div>
            <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 24, color: p.color, marginBottom: 2 }}>{p.price === 0 ? 'Free' : `$${p.price}`}<span style={{ fontSize: 11, color: '#6A6560' }}>{p.period}</span></div>
            <div style={{ height: 1, background: 'rgba(201,168,76,.12)', margin: '10px 0' }} />
            {p.features.map(f => <div key={f} style={{ fontSize: 10, color: '#E8E4D9', padding: '3px 0' }}>✓ {f}</div>)}
            {p.locked.map(f => <div key={f} style={{ fontSize: 10, color: '#3A3830', padding: '3px 0' }}>✕ {f}</div>)}
            <button style={{ width: '100%', padding: 8, borderRadius: 8, marginTop: 12, fontSize: 11, fontFamily: 'inherit', cursor: 'pointer', background: p.current ? 'transparent' : p.color, color: p.current ? p.color : '#08080E', border: `1px solid ${p.color}` }}>
              {p.current ? 'Current plan' : `Upgrade to ${p.name}`}
            </button>
          </div>
        ))}
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 12 }}>
        <div style={card}>
          <div style={ct}>Google Play license</div>
          {[['Server','✓ Connected',true],['Signature','Verified ✓',true],['Source','Play Store only',false],['Anti-clone','Active',true],['Next billing','Jun 9 · $149',false]].map(([l,v,ok]) =>
            <div key={l} style={{ display: 'flex', justifyContent: 'space-between', padding: '5px 0', borderBottom: '1px solid rgba(255,255,255,.04)', fontSize: 10 }}>
              <span style={{ color: '#6A6560' }}>{l}</span><span style={{ color: ok ? '#5DC48A' : '#E8E4D9' }}>{v}</span>
            </div>
          )}
        </div>
        <div style={card}>
          <div style={ct}>Payment methods</div>
          {[['Google Play Billing','Primary','#5DC48A'],['Stripe / Credit card','Backup','#7AAAE0'],['PayPal','Backup','#7AAAE0']].map(([m,s,c]) =>
            <div key={m} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '7px 0', borderBottom: '1px solid rgba(255,255,255,.04)', fontSize: 11 }}>
              <span>{m}</span><span style={{ background: c + '20', color: c, fontSize: 9, padding: '1px 7px', borderRadius: 10 }}>{s}</span>
            </div>
          )}
        </div>
        <div style={card}>
          <div style={ct}>Recent invoices</div>
          {['May 2026','Apr 2026','Mar 2026','Feb 2026'].map(m => <div key={m} style={{ display: 'flex', justifyContent: 'space-between', padding: '5px 0', borderBottom: '1px solid rgba(255,255,255,.04)', fontSize: 10 }}><span style={{ color: '#6A6560' }}>{m}</span><span style={{ color: '#5DC48A' }}>$149 Paid</span></div>)}
        </div>
      </div>
    </div>
  )
}

// ─────────────────────────────────────────────────────────────────────────────
// pages/Security.jsx
// ─────────────────────────────────────────────────────────────────────────────
export function Security() {
  const CHECKS = [
    { icon: 'ti-lock',       label: 'TLS 1.3 encryption',    status: 'Active',     ok: true },
    { icon: 'ti-fingerprint',label: 'Face biometric',         status: 'Active',     ok: true },
    { icon: 'ti-credit-card',label: 'PCI-DSS compliance',     status: 'Active',     ok: true },
    { icon: 'ti-key',        label: '2FA admin login',         status: 'Recommended',ok: false },
    { icon: 'ti-copy-off',   label: 'Anti-clone (Google Play)',status: 'Enforced',   ok: true },
    { icon: 'ti-database',   label: 'GDPR + CCPA',             status: 'Compliant',  ok: true },
    { icon: 'ti-eye-off',    label: 'Data retention',          status: '90 days',    ok: true },
    { icon: 'ti-activity',   label: 'Audit logging',           status: 'Active',     ok: true },
  ]
  const AUDIT = [
    ['✓','Admin login — 10:24 AM · IP 192.168.1.1','#5DC48A'],
    ['✓','Face match Capt. Williams — 10:31 AM','#5DC48A'],
    ['✓','Booking #1042 created — 10:33 AM','#5DC48A'],
    ['✓','WhatsApp sent → Williams — 10:33 AM','#5DC48A'],
    ['✓','OpenTable reserved Spago — 10:45 AM','#5DC48A'],
    ['⚠','Failed login attempt blocked — 11:02 AM','#C9A84C'],
    ['✓','License verified — 11:15 AM Play Store','#5DC48A'],
    ['✓','Payment $480 processed — 11:20 AM','#5DC48A'],
  ]
  return (
    <div style={{ color: '#E8E4D9', fontFamily: "'DM Sans', sans-serif" }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 12 }}>
        <div style={card}>
          <div style={ct}>Security status</div>
          {CHECKS.map(c => (
            <div key={c.label} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '7px 0', borderBottom: '1px solid rgba(255,255,255,.04)', fontSize: 11 }}>
              <i className={`ti ${c.icon}`} style={{ fontSize: 13, color: c.ok ? '#5DC48A' : '#C9A84C', width: 14 }} />
              <span style={{ flex: 1 }}>{c.label}</span>
              <span style={{ background: c.ok ? 'rgba(58,125,90,.15)' : 'rgba(201,168,76,.12)', color: c.ok ? '#5DC48A' : '#C9A84C', fontSize: 9, padding: '1px 7px', borderRadius: 10 }}>{c.status}</span>
            </div>
          ))}
        </div>
        <div style={card}>
          <div style={ct}>Audit log</div>
          {AUDIT.map(([ic, msg, color], i) => <div key={i} style={{ fontSize: 10, padding: '4px 0', color: '#6A6560', borderBottom: '1px solid rgba(255,255,255,.04)' }}><span style={{ color }}>{ic} </span>{msg}</div>)}
        </div>
      </div>
      <div style={card}>
        <div style={ct}>Data collected per customer</div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 8 }}>
          {['📷 Face embedding (AES-256 encrypted)', '👤 Name, airline, badge #', '📱 WhatsApp number', '✉️ Email address', '👥 Group size & age range', '🏙 City history & preferences', '🛣 Route & venue history', '💳 Payment token (never raw card)'].map((d, i) => (
            <div key={i} style={{ background: '#1C1C27', borderRadius: 7, padding: '8px 10px', fontSize: 10, color: '#6A6560' }}>{d}</div>
          ))}
        </div>
      </div>
    </div>
  )
}

// ─────────────────────────────────────────────────────────────────────────────
// Shared style tokens
// ─────────────────────────────────────────────────────────────────────────────
const card = { background: '#16161F', border: '1px solid rgba(201,168,76,.15)', borderRadius: 10, padding: 13 }
const ct   = { fontSize: 8, letterSpacing: 1.4, textTransform: 'uppercase', color: '#6A6560', marginBottom: 10 }
const fg   = { marginBottom: 9 }
const lbl  = { display: 'block', fontSize: 8, letterSpacing: 1, textTransform: 'uppercase', color: '#6A6560', marginBottom: 4 }
const inp  = { width: '100%', padding: '7px 10px', background: '#1C1C27', border: '1px solid rgba(201,168,76,.18)', borderRadius: 6, color: '#E8E4D9', fontFamily: 'inherit', fontSize: 12, outline: 'none', boxSizing: 'border-box' }
const btnPrimary = { display: 'inline-flex', alignItems: 'center', gap: 5, padding: '8px 14px', borderRadius: 7, fontSize: 11, fontFamily: 'inherit', cursor: 'pointer', fontWeight: 500 }
